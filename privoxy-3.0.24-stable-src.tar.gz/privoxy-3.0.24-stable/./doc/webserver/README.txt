All files contained in this directory should eventually be
on the project's homepage 

   ijbswa.sourceforge.net:/home/groups/i/ij/ijbswa/htdocs/

which is indeed http://ijbswa.sourceforge.net 
and http://www.privoxy.org/.

-Stefan, April 2002