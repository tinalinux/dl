#ifndef _LINUX_TYPES_H
#define _LINUX_TYPES_H

#define unchar unsigned char
#define ushort unsigned short
#define uint unsigned int
#define ulong unsigned long

#define u_char unsigned char
#define u_short unsigned short
#define u_int unsigned int
#define u_long unsigned long

#endif /* _LINUX_TYPES_H */
