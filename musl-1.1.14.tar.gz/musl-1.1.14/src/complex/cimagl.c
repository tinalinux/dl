#include "libm.h"

long double (cimagl)(long double complex z)
{
	return cimagl(z);
}
