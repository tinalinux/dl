SHA-2 Lua binding

Copyright (c) 2010 Cosmin Apreutesei

Author:		Cosmin Apreutesei <cosmin.apreutesei@gmail.com>
License:	MIT (see LICENSE.txt)
Homepage:	http://code.google.com/p/sha2/

For up-to-date information please visit the project's website.
