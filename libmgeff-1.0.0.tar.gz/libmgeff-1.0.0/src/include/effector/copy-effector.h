#ifndef _EFF_EFFECTORCOPY_H
#define _EFF_EFFECTORCOPY_H
#include "effector.h"

void effcopyeffector_ondraw(MGEFF_ANIMATION animation, MGEFF_EFFECTOR _effector, 
        HDC sink_dc, int id, void* value);
#endif
