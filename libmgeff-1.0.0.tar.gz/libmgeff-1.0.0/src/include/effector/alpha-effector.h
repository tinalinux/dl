#ifndef _EFF_EFFECTORALPHA_H
#define _EFF_EFFECTORALPHA_H
#include "effector.h"

void effalphaeffector_ondraw(MGEFF_ANIMATION animation, MGEFF_EFFECTOR _effector, 
        HDC sink_dc, int id, void* value);
#endif
