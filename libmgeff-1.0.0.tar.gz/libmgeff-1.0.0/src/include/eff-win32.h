#ifndef _EFF_WIN32_H
#define _EFF_WIN32_H

#ifdef __cplusplus
extern "C" {
#endif

int eff_time_win32(void);

#ifdef __cplusplus
}
#endif

#endif /* _EFF_WIN32_H */
