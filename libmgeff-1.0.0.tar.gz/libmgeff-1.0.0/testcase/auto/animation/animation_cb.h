#ifndef __ANIMATION_CB_H__
#define __ANIMATION_CB_H__ 

extern void test_animation_finish_callback();
extern void test_animation_statechanged_callback();
extern void test_animation_curloopchanged_callback();
extern void test_animation_dirchanged_callback();
extern void test_animation_varmalloc_calcvalue_callback();

#endif
