
#ifndef _ANIMATION_MISC_H
#define _ANIMATION_MISC_H
extern void test_animation_float ();
extern void test_animation_double ();
extern void test_animation_rect ();
extern void test_animation_point ();
extern void test_animation_pointf ();
extern void test_animation_3dpoint();
extern void test_animation_3dpointf();

#endif /*_ANIMATION_MISC_H*/

