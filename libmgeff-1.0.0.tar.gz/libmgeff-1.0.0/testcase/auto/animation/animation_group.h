#ifndef _ANIMATION_GROUP_H
#define _ANIMATION_GROUP_H

extern void test_animation_group_duration ();
extern void test_animation_group_finished ();
extern void test_animation_group_direction ();
extern void test_animation_group_loopcount ();
#endif
