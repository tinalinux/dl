#ifndef _ANIMATION_INT_H
#define _ANIMATION_INT_H

extern void test_animation_pause();
extern void test_animation_createex ();
extern void test_animation_state_change ();
extern void test_animation_finished ();
extern void test_animation_duration();
extern void test_animation_loopcount ();
extern void test_animation_direction();
extern void test_animation_paramsetting ();
extern void test_animation_fps ();

#endif
