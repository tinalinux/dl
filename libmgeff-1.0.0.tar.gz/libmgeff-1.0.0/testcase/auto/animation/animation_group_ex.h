#ifndef _ANIMATION_GROUP_EX_H_
#define _ANIMATION_GROUP_EX_H

extern void test_animation_group_pause_resume(enum EffAnimationType type);
extern void test_animation_group_create(enum EffAnimationType type);
extern void test_animation_group_stop(enum EffAnimationType type);
extern void test_animation_group_delete(enum EffAnimationType type);
extern void test_animation_group_wait(enum EffAnimationType type);

#endif
