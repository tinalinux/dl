/****************************************/
/* This file is generate by mstudio,    */
/* Please Don't edit it.                */
/*                                      */
/* This file define the IDs used by     */
/* resource.                            */
/****************************************/



#ifndef _RESOURCE_ID_H_
#define _RESOURCE_ID_H_

#define ID_MAINWND1			0x80001
#define ID_MLEDIT_CODE			0xa
#define ID_RECT_CURVE			0xb
#define ID_RECTANGLE2			0xc
#define ID_RECTANGLE3			0xd
#define ID_STATIC1			0xe
#define ID_STATIC2			0xf
#define ID_SPINBOX_DURATION			0x10
#define ID_LISTBOX1			0x11
#define ID_COMBOBOX_CURVE			0x12
#define ID_BUTTON_START			0x13
#define ID_BUTTON_STOP			0x14
#define ID_TIMER1			0x15
#endif /*_RESOURCE_ID_H_*/
