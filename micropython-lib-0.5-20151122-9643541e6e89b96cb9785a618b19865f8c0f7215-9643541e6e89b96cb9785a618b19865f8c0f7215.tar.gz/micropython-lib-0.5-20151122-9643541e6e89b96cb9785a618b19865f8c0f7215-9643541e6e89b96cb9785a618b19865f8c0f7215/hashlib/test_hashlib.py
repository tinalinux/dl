from hashlib.sha256 import test as sha256_test
from hashlib.sha512 import test as sha512_test


sha256_test()
sha512_test()
print("OK")
