#!/bin/sh
echo "WARNING: You have called autogen.sh, use autoreconf -fi instead, I will do it for you this time :)"
autoreconf -fi
