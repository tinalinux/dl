var HID = require('../');

console.log('devices:', HID.devices());
