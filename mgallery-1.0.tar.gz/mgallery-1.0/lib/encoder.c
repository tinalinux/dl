#include "encoder.h"
#include <string.h>

void *videoEncOpen(void *param)
{
    return NULL;
}

int videoEncCmd(void *handle,unsigned int cmd,unsigned int param)
{
    return 0;
}

int videoEncClose(void *handle,void *param)
{
    return 0;
}

void *imageEncOpen(void *param)
{
    return NULL;
}

int imageEncCmd(void *handle,unsigned int cmd,unsigned int param)
{
    return 0;
}

int imageEncClose(void *handle,void *param)
{
    return 0;
}

void *audioEncOpen(void *param)
{
    return NULL;
}

int audioEncCmd(void *handle,unsigned int cmd,unsigned int param)
{
    return 0;
}

int audioEncClose(void *handle,void *param)
{
    return 0;
}
