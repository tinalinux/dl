#include "decoder.h"
#include <string.h>

void *videoDecOpen(void *param)
{
    return NULL;
}

int videoDecCmd(void *handle,unsigned int cmd,unsigned int param)
{
    return 0;
}

int videoDecClose(void *handle,void *param)
{
    return 0;
}

void *audioDecOpen(void *param)
{
    return NULL;
}

int audioDecCmd(void *handle,unsigned int cmd,unsigned int param)
{
    return 0;
}

int audioDecClose(void *handle,void *param)
{
    return 0;
}

void *imageDecOpen(void *param)
{
    return NULL;
}

int imageDecCmd(void *handle,unsigned int cmd,unsigned int param)
{
    return 0;
}

int imageDecClose(void *handle,void *param)
{
    return 0;
}

void *radioOpen(void *param)
{
    return NULL;
}

int radioCmd(void *handle,unsigned int cmd,unsigned int param)
{
    return 0;
}

int radioClose(void *handle,void *param)
{
    return 0;
}
