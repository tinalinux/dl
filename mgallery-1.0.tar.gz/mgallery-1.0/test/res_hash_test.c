
#include <stdio.h>
#include "pmp.h"
#include "res_hash.h"

int main()
{
    pmp_res_hash_retrive_unit ("/res/desktop/video.png");
    
    return 0;
}
