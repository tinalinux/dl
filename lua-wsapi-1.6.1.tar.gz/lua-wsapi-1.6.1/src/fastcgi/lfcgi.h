/* $Id: lfcgi.h,v 1.1 2007/10/30 23:44:45 mascarenhas Exp $ */
LUALIB_API int luaopen_lfcgi (lua_State *L);
